/* Name           : Mohamed Asad Azim Bandarkar
 * Student Number : 4271451
 * Practical 2    : Term 4 Practical 2 Q1
 * Graph used     : Kruskals Algorithm
 * CITATIONS      : https://github.com/SleekPanther/kruskals-algorithm-minimum-spanning-tree-mst
 *                  https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/Comparator.html 
 *                  https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/Arrays.html#Creating-Arrays 
 */

import java.util.*;

public class KruskalAlgorithmQ1 {
    static class Edge {
        char source;                                                      //Source vertex of the edge
        char destination;                                                 //Destination vertex of the edge
        int weight;                                                       //Weight (cost) of the edge

        // Edge Class Constructor
        public Edge(char source, char destination, int weight) {
            this.source = source;
            this.destination = destination;
            this.weight = weight;
        }
    
    }

    public static void main(String[] args) {
        //Graph as a list of edges with Starting and Ending letter labels
        List<Edge> edges = Arrays.asList(
                new Edge('x', 'u', 30),                             //left part of the graph starting point
                new Edge('u', 'f', 3),
                new Edge('u', 'i', 20),
                new Edge('x', 'g', 4),
                new Edge('g', 'r', 12),
                new Edge('i', 't', 11),
                new Edge('t', 'w', 17),
                new Edge('w', 'n', 55),
                new Edge('i', 'j', 44),
                new Edge('i', 'e', 76),
                new Edge('t', 'j', 8),
                new Edge('t', 'y', 21),
                new Edge('j', 'y', 6),                               // left part of the graph ends here
                new Edge('h', 'k', 32),                              // right part of the graph starts here
                new Edge('k', 'p', 14),
                new Edge('p', 'd', 18),
                new Edge('k', 'c', 7),
                new Edge('d', 'c', 5),
                new Edge('c', 'q', 25),
                new Edge('c', 's', 19),
                new Edge('q', 's', 16),
                new Edge('s', 'm', 9),
                new Edge('m', 'b', 7),
                new Edge('s', 'b', 13),
                new Edge('b', 'k', 35),
                new Edge('c', 'l', 22)                               // right part of the graph ends
        );

        // Find the Minimum Spanning Tree
        int[] mst = findMST(edges.toArray(new Edge[0]), 200);                        // Maximum weight initialisation of 200

        // Printing the minimum spanning tree edges to the screen
        System.out.println("Minimum spanning tree edges:");
        for (Edge edge : edges) {
            System.out.println(edge.source + " - " + edge.destination + " (" + edge.weight + ")"); // printing starting
                                                                                                   // edge label,ending
                                                                                                   // edge label and its
                                                                                                   // weight
        }

        // Calculating the minimum cost of keeping the cities connected.
        int totalCost = Arrays.stream(mst).sum();                                                // Calculate the sum of all elements in the 'mst' array //Citation
                                                                                                 // above
        System.out.println("Minimum cost of keeping the cities connected: " + totalCost);        // Print the total cost of
                                                                                                 // connecting the cities
    }

    public static int[] findMST(Edge[] edges, int numVertices) {
        // Sort the edges in ascending order of weight.
        Arrays.sort(edges, Comparator.comparingInt(e -> e.weight));                                 //arranges the edges by their weight in ascending
                                                                                                    //order //citation:
                                                                                                    //https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/Comparator.html

        // Create an array to represent the MST.
        int[] mst = new int[numVertices - 1];                                                       // array size is 'numVertices - 1' because a MST has 'numVertices - 1'
                                                                                                    // edges
        int mstIndex = 0;                                                                           // Initialize an index 'mstIndex' to keep track of the current position in the
                                                                                                    // 'mst' array.Index is used to add edges to the MST as they are selected.

        // Create an array to track the parent of each vertex (for cycle detection).
        char[] parent = new char[numVertices];                                                     // The array has 'numVertices' elements to represent each vertex in the
                                                                                                   // graph
        Arrays.fill(parent, '\0');                                                             // Citation:
                                                                                                   // https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/Arrays.html#Creating-Arrays.
                                                                                                   // Initialize the 'parent' array by filling it with null characters ('\0').
                                                                                                   // This initial state implies that no vertex has a parent assigned initially.

        for (Edge edge : edges) {                                                                  // Iterate through each edge in the 'edges' list
            char sourceRoot = findRoot(parent, edge.source);                                       // Finding the root of the 'source' vertex for the current
                                                                                                   // edge
            char destRoot = findRoot(parent, edge.destination);                                    // Finding the root (parent) of the 'destination' vertex
                                                                                                   // for the current edge

            // Check if adding the edge would create a cycle.
            if (sourceRoot != destRoot) {                                                          // Check if the source and destination vertices have different roots
                mst[mstIndex++] = edge.weight;                                                     // Add the weight of the current edge to the Minimum Spanning Tree
                parent[sourceRoot] = destRoot;                                                     // Update the 'parent' array to merge the two components by making
                                                                                                   // 'sourceRoot' a child of 'destRoot'
            } // Citation above

            // If the MST is complete, exit the loop.
            if (mstIndex == numVertices - 1) {
                break;
            }
        }

        return mst;
    }

    private static char findRoot(char[] parent, char vertex) {                                                // Define a method to find the root of a vertex in a set
        if (parent[vertex] == '\0') {                                                                         // Check if the 'vertex' has no parent then it's the root
                                                                                                              // If the 'parent' array contains a null character ('\0'), it means 'vertex' is
                                                                                                              // the root //Citation above
            return vertex;
        } else {
            return findRoot(parent, parent[vertex]);                                                           // Recursively call 'findRoot' to find the ultimate root (parent)
                                                                                                               // of 'vertex' by //citation above
                                                                                                               // following the chain of parent vertices until the root is
                                                                                                               // reached.
        }
    }
}
