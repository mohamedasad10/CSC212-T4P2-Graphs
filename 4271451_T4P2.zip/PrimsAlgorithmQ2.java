/* Name           : Mohamed Asad Azim Bandarkar
 * Student Number : 4271451
 * Practical 2    : Term 4 Practical 2 Q2
 * Graph used     : Prims Algorithm
 * CITATIONS      : https://github.com/sangamsahai/Minimum-Spanning-Tree--Prims-Algorithm---Java-Implementation/blob/master/MinimumSpanningTreePrims.java
 *                  https://github.com/sangamsahai/Minimum-Spanning-Tree--Prims-Algorithm---Java-Implementation/blob/master/MinimumSpanningTreePrims.java
 *                  https://www.geeksforgeeks.org/prims-minimum-spanning-tree-mst-greedy-algo-5/     
*/
import java.util.*;

public class PrimsAlgorithmQ2 {
    static class Edge {
        char source;                                                      //Source vertex of the edge
        char destination;                                                 //Destination vertex of the edge
        int weight;                                                       //Weight (cost) of the edge

        // Edge Class Constructor
        public Edge(char source, char destination, int weight) {
            this.source = source;
            this.destination = destination;
            this.weight = weight;
        }
    }

    public static void main(String[] args) {
        //Graph as a list of edges with Starting and Ending letter labels
        List<Edge> edges = Arrays.asList(
            new Edge('x', 'u', 30),
            new Edge('u', 'f', 3),
            new Edge('u', 'i', 20),
            new Edge('x', 'g', 4),
            new Edge('g', 'r', 12),
            new Edge('i', 't', 11),
            new Edge('t', 'w', 17),
            new Edge('w', 'n', 55),
            new Edge('i', 'j', 44),
            new Edge('i', 'e', 76),
            new Edge('t', 'j', 8),
            new Edge('t', 'y', 21),
            new Edge('j', 'y', 6),
            new Edge('h', 'k', 32),
            new Edge('k', 'p', 14),
            new Edge('p', 'd', 18),
            new Edge('k', 'c', 7),
            new Edge('d', 'c', 5),
            new Edge('c', 'q', 25),
            new Edge('c', 's', 19),
            new Edge('q', 's', 16),
            new Edge('s', 'm', 9),
            new Edge('m', 'b', 7),
            new Edge('s', 'b', 13),
            new Edge('b', 'k', 35),
            new Edge('c', 'l', 22),
            new Edge('y', 'k', 24),                           //new edges added for Question 2
            new Edge('j', 'p', 10),
            new Edge('j', 'h', 52),
            new Edge('n', 'h', 25),
            new Edge('j', 'e', 31),
            new Edge('g', 'k', 34)
        );

        List<Edge> minimumSpanningTree = primMST(edges);                               //Find the minimum spanning tree using Prim's algorithm //citation above

        System.out.println("Minimum spanning tree edges:");
        for (Edge edge : minimumSpanningTree) {                                        //Printing the minimum spanning tree edges to the screen
            System.out.println(edge.source + " - " + edge.destination + " (" + edge.weight + ")");
        }

        int totalCost = 0;                                                             //variable to store the total cost of the MST
        for (Edge edge : minimumSpanningTree) {                                        //Add the weight of each edge in the minimum spanning tree to the total cost
            totalCost += edge.weight;
        }
        System.out.println("Minimum cost of keeping the cities connected: " + totalCost);
    }

    public static List<Edge> primMST(List<Edge> edges) {
        Set<Character> visited = new HashSet<>();                                         //list to store the edges in the minimum spanning tree
        List<Edge> minimumSpanningTree = new ArrayList<>();

        char startVertex = edges.get(0).source;                                     //starting vertex
        visited.add(startVertex);

        while (visited.size() < edges.size() + 1) {                                       //Search all vertices  //citation above
            Edge minEdge = null;

            //Citation: https://www.geeksforgeeks.org/prims-minimum-spanning-tree-mst-greedy-algo-5/
            //Check if the source is visited, and the destination is not
            for (Edge edge : edges) {                                                               //initiates a loop that iterates over each element in the edges collection, one at a time
                if (visited.contains(edge.source) && !visited.contains(edge.destination)) {         //It checks if the edge's source vertex is already in the visited collection.  It checks if the edge's destination vertex is not in the visited collection.
                    if (minEdge == null || edge.weight < minEdge.weight) {                          //checks if the minEdge variable is currently null. This is used to initialize minEdge on the first iteration. checks if the weight of the current edge is less than the weight of the minEdge.
                        minEdge = edge;                                                             //line sets the minEdge variable to the current edge
                    }
                }
            }

            //Citation above 
            if (minEdge != null) {
                visited.add(minEdge.destination);                                          //marks the destination vertex of the minimum-weight edge as visited
                minimumSpanningTree.add(minEdge);                                          //adds the minimum-weight edge to the list
            } else {
                break;                                                                     //If no suitable edge is found, exit the loop
            }
        }

        return minimumSpanningTree;
    }
}
